/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app_netxduo.c
  * @author  MCD Application Team
  * @brief   NetXDuo applicative file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "app_netxduo.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "app_azure_rtos.h"
#include "main.h"
#include "nx_ip.h"
#include "nxd_dns.h"
#include "nxd_sntp_client.h"

#include "nx_driver_stm32_cellular.h"
#include "tim.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
TX_THREAD AppMainThread;

TX_SEMAPHORE IpAddrSemaphore; /* release when an IpAddr is obtained */



NX_PACKET_POOL        AppPool;
NX_IP                 IpInstance;
static NX_DNS         DnsClient;
static NX_SNTP_CLIENT SntpClient;

ULONG   IpAddress;
ULONG   NetMask;
ULONG   sntp_usec; //Global variable for sntp seconds
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define DEFAULT_MAIN_PRIORITY       10
#define THREAD_MEMORY_SIZE          (2 * DEFAULT_MEMORY_SIZE)

/* Default time. GMT: Friday, Jan 1, 2022 12:00:00 AM. Epoch timestamp: 1640995200.  */
#ifndef SYSTEM_TIME
#define SYSTEM_TIME              1640995200
#endif /* SYSTEM_TIME  */

/* EPOCH_TIME_DIFF is equivalent to 70 years in sec
   calculated with www.epochconverter.com/date-difference
   This constant is used to delete difference between :
   Epoch converter (referenced to 1970) and SNTP (referenced to 1900) */
#define EPOCH_TIME_DIFF          2208988800

#define SNTP_SYNC_MAX            (uint32_t)30
#define SNTP_UPDATE_MAX          (uint32_t)10
#define SNTP_UPDATE_INTERVAL     (NX_IP_PERIODIC_RATE / 2)

#define IP_ADDR_TIMEOUT          (50*NX_IP_PERIODIC_RATE)

#define SAMPLE_IP_THREAD_PRIORITY     DEFAULT_PRIORITY
#define SAMPLE_IP_THREAD_STACK_SIZE   (2 * DEFAULT_MEMORY_SIZE)

#define SAMPLE_NETWORK_CONFIGURE_START          nx_driver_stm32_cellular_configure
#define SAMPLE_NETWORK_DRIVER                   nx_driver_stm32_cellular

#define NTP_FRACTIONAL_RESOLUTION 4294967296.0  // 2^32

#define SYNC_DURATION             100  // Total sync duration in seconds
#define DRIFT_THRESHOLD_SECONDS   1    // Maximum acceptable drift in seconds
#define SYNC_INTERVAL_SECONDS     1   // Interval between sync checks in seconds
#define SYNC_INTERVAL_TICKS       (SYNC_INTERVAL_SECONDS * TX_TIMER_TICKS_PER_SECOND) // Interval in ThreadX ticks

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
/* System clock time for UTC.  */
static ULONG            unix_time_base;

static const char *sntp_servers[] =
{
  "time.google.com",
  "time1.google.com",
  "time2.google.com",
  "time3.google.com"
};

static UINT sntp_server_index;

static ULONG dns_server_address[3];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
static VOID App_Main_Thread_Entry(ULONG thread_input);

static VOID ip_address_change_notify_callback(NX_IP *ip_instance, VOID *ptr);

static UINT dns_create(NX_DNS *dns_ptr);
static UINT unix_time_get(ULONG *unix_time);
static UINT sntp_time_sync_internal(ULONG sntp_server_address);
static UINT sntp_time_sync(VOID);

/* Include the sample interface.  */
extern VOID sample_init(void);
extern VOID sample_start(NX_IP *ip_ptr, NX_PACKET_POOL *pool_ptr, NX_DNS *dns_ptr,
                         UINT(*unix_time_callback)(ULONG *unix_time));
/* USER CODE END PFP */
/**
  * @brief  Application NetXDuo Initialization.
  * @param memory_ptr: memory pointer
  * @retval int
  */
UINT MX_NetXDuo_Init(VOID *memory_ptr)
{
  UINT ret = NX_SUCCESS;
  TX_BYTE_POOL *byte_pool = (TX_BYTE_POOL*)memory_ptr;

  /* USER CODE BEGIN MX_NetXDuo_MEM_POOL */

  /* USER CODE END MX_NetXDuo_MEM_POOL */

  /* USER CODE BEGIN MX_NetXDuo_Init */
  printf("Nx_TCP_Echo_Client application started.\n");

  CHAR *pointer;

  /* Allocate the memory for packet_pool.  */
  if (tx_byte_allocate(byte_pool, (VOID **) &pointer, NX_PACKET_POOL_SIZE, TX_NO_WAIT) != TX_SUCCESS)
  {
    printf("tx_byte_allocate (packet_pool) fail\r\n");
    return TX_POOL_ERROR;
  }

  /* Create the Packet pool to be used for packet allocation */
  ret = nx_packet_pool_create(&AppPool, "Main Packet Pool", PAYLOAD_SIZE, pointer, NX_PACKET_POOL_SIZE);

  if (ret != NX_SUCCESS)
  {
    printf("nx_packet_pool_create fail: %u\r\n", ret);
    return NX_NOT_ENABLED;
  }

  /* Allocate the memory for Ip_Instance */
  if (tx_byte_allocate(byte_pool, (VOID **) &pointer, SAMPLE_IP_THREAD_STACK_SIZE, TX_NO_WAIT) != TX_SUCCESS)
  {
    printf("tx_byte_allocate (Ip_Instance) fail\r\n");
    return TX_POOL_ERROR;
  }

  printf("Create IP instance...\r\n");

  /* Create the main NX_IP instance */
  ret = nx_ip_create(&IpInstance, "Main Ip instance", NULL_ADDRESS, NULL_ADDRESS, &AppPool, SAMPLE_NETWORK_DRIVER,
                     pointer, SAMPLE_IP_THREAD_STACK_SIZE, SAMPLE_IP_THREAD_PRIORITY);

  if (ret != NX_SUCCESS)
  {
    printf("nx_ip_create fail: %u\r\n", ret);
    return NX_NOT_ENABLED;
  }

  /* Enable the ICMP */
  ret = nx_icmp_enable(&IpInstance);

  if (ret != NX_SUCCESS)
  {
    printf("nx_icmp_enable fail: %u\r\n", ret);
    return NX_NOT_ENABLED;
  }

  /* Enable the UDP protocol required for DHCP communication */
  ret = nx_udp_enable(&IpInstance);

  if (ret != NX_SUCCESS)
  {
    printf("nx_udp_enable fail: %u\r\n", ret);
    return NX_NOT_ENABLED;
  }

  /* Enable the TCP protocol */
  ret = nx_tcp_enable(&IpInstance);

  if (ret != NX_SUCCESS)
  {
    printf("nx_tcp_enable fail: %u\r\n", ret);
    return NX_NOT_ENABLED;
  }

  /* Initialize sample */
  sample_init();

  /* Allocate the memory for main thread   */
  if (tx_byte_allocate(byte_pool, (VOID **) &pointer, THREAD_MEMORY_SIZE, TX_NO_WAIT) != TX_SUCCESS)
  {
    printf("tx_byte_allocate (main thread) fail\r\n");
    return TX_POOL_ERROR;
  }

  /* Create the main thread */
  ret = tx_thread_create(&AppMainThread, "App Main thread", App_Main_Thread_Entry, 0, pointer, THREAD_MEMORY_SIZE,
                         DEFAULT_MAIN_PRIORITY, DEFAULT_MAIN_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  if (ret != TX_SUCCESS)
  {
    printf("tx_thread_create (App Main thread) fail: %u\r\n", ret);
    return NX_NOT_ENABLED;
  }

  /* Create IpAddr semaphore */
  tx_semaphore_create(&IpAddrSemaphore, "IpAddr Semaphore", 0);
  /* USER CODE END MX_NetXDuo_Init */

  return ret;
}

/* USER CODE BEGIN 1 */

ULONG GetTimeInSeconds(void)
{
	ULONG ticks = tx_time_get();
	return (uint64_t)(ticks / TX_TIMER_TICKS_PER_SECOND);
}

/**
  * @brief  Main thread entry.
  * @param thread_input: ULONG user argument (unused argument)
  * @retval none
  */
static VOID App_Main_Thread_Entry(ULONG thread_input)
{
  UINT ret = NX_SUCCESS;
  ULONG initial_sys_time, initial_sntp_time;
  ULONG current_sys_time, current_sntp_time;
  ULONG elapsed_time=0;
  ULONG drift;

  NX_PARAMETER_NOT_USED(thread_input);

  printf("Get IP Address...\r\n");

  ret = nx_ip_address_change_notify(&IpInstance, ip_address_change_notify_callback, NULL);
  if (ret != NX_SUCCESS)
  {
    printf("nx_ip_address_change_notify fail: %u\r\n", ret);
    Error_Handler();
  }

  SAMPLE_NETWORK_CONFIGURE_START(&IpInstance, &dns_server_address[0]);

  /* wait until an IP address is ready */
  if (tx_semaphore_get(&IpAddrSemaphore, IP_ADDR_TIMEOUT) != TX_SUCCESS)
  {
    printf("IP address timeout fail\r\n");
    Error_Handler();
  }

  ret = nx_ip_address_get(&IpInstance, &IpAddress, &NetMask);

  if (ret != TX_SUCCESS)
  {
    printf("nx_ip_address_get fail: %u\r\n", ret);
    Error_Handler();
  }

  PRINT_IP_ADDRESS("STM32 IP Address: ", IpAddress);

  /* Create a DNS client */
  ret = dns_create(&DnsClient);

  if (ret != NX_SUCCESS)
  {
    printf("dns_create fail: %u\r\n", ret);
    Error_Handler();
  }

  /* Sync up time by SNTP at start up. */
  ret = sntp_time_sync();

  initial_sntp_time = sntp_usec;
  initial_sys_time = GetTimeInSeconds();

 /* while(elapsed_time<100)
  {
	  printf("Counter: %d | ",TIM2->CCR2 + TIM2->CNT);
	  elapsed_time+=1;
	  tx_thread_sleep(0.1);
  }


	elapsed_time =0;*/

  /* Check status.  */
  if (ret != NX_SUCCESS)
  {
    printf("SNTP Time Sync failed.\r\n");
    Error_Handler();
  }

  while(elapsed_time<=100){
  		  //current_sys_time = TIM2->CCR2 + TIM2->CNT;
	  	  current_sys_time = GetTimeInSeconds();
  		  ret = sntp_time_sync();
  		  current_sntp_time = sntp_usec;
  		  //Drift calculation
  		  printf("SNTP Difference: %ld | ", current_sntp_time-initial_sntp_time);
  		  /*printf("\ncurrent_sntp_time: %ld", current_sntp_time);
  		  printf("\ninitial_sntp_time: %ld", initial_sntp_time);
  		  printf("\ncurrent_sys_time: %ld", current_sys_time);
  		  printf("\ninitial_sys_time: %ld", initial_sys_time);
  		  */
  		  drift = (current_sntp_time-initial_sntp_time)-(current_sys_time-initial_sys_time);
  		  printf("Drift in sec: %ld | ", drift);
  		  elapsed_time += 4;
  		  initial_sntp_time=current_sntp_time;
  		  initial_sys_time = current_sys_time;
  		  tx_thread_sleep(100); //delay of 1 seconds
  	  }

  /* Start sample. */
  sample_start(&IpInstance, &AppPool, &DnsClient, unix_time_get);

  /* this thread is not needed any more, we relinquish it */
  tx_thread_relinquish();
}

#if 0
static VOID App_Main_Thread_Entry(ULONG thread_input)
{
  UINT ret = NX_SUCCESS;
  ULONG et=0;

  NX_PARAMETER_NOT_USED(thread_input);

  printf("Get IP Address...\r\n");

  ret = nx_ip_address_change_notify(&IpInstance, ip_address_change_notify_callback, NULL);
  if (ret != NX_SUCCESS)
  {
    printf("nx_ip_address_change_notify fail: %u\r\n", ret);
    Error_Handler();
  }

  SAMPLE_NETWORK_CONFIGURE_START(&IpInstance, &dns_server_address[0]);

  /* wait until an IP address is ready */
  if (tx_semaphore_get(&IpAddrSemaphore, IP_ADDR_TIMEOUT) != TX_SUCCESS)
  {
    printf("IP address timeout fail\r\n");
    Error_Handler();
  }

  ret = nx_ip_address_get(&IpInstance, &IpAddress, &NetMask);

  if (ret != TX_SUCCESS)
  {
    printf("nx_ip_address_get fail: %u\r\n", ret);
    Error_Handler();
  }

  PRINT_IP_ADDRESS("STM32 IP Address: ", IpAddress);

  /* Create a DNS client */
  ret = dns_create(&DnsClient);

  if (ret != NX_SUCCESS)
  {
    printf("dns_create fail: %u\r\n", ret);
    Error_Handler();
  }

  /* Sync up time by SNTP at start up. */
  ret = sntp_time_sync();

  /* Check status.  */
  if (ret != NX_SUCCESS)
  {
    printf("SNTP Time Sync failed.\r\n");
    Error_Handler();
  }


  while(et<100){
	  if(tx_semaphore_get(&GpioSemaphore, TX_WAIT_FOREVER)==TX_SUCCESS)
	  {
	  	  printf("Register2: %lu | ", TIM2->CNT);
	  	  printf("Register1: %lu | ", TIM3->CNT);
	  	  et+=1;
	  }
  	  tx_thread_sleep(100);
  }

  /* Start sample. */
  sample_start(&IpInstance, &AppPool, &DnsClient, unix_time_get);

  /* this thread is not needed any more, we relinquish it */
  tx_thread_relinquish();
}
#endif

/**
  * @brief ip address change callback.
  * @param ip_instance: NX_IP instance
  * @param ptr: user data
  * @retval none
  */
static VOID ip_address_change_notify_callback(NX_IP *ip_instance, VOID *ptr)
{
  /* release the semaphore as soon as an IP address is available */
  tx_semaphore_put(&IpAddrSemaphore);
}

/**
  * @brief  DNS Create Function.
  * @param dns_ptr
  * @retval ret
  */
static UINT dns_create(NX_DNS *dns_ptr)
{
  UINT status;

  /* Create a DNS instance for the Client */
  status = nx_dns_create(dns_ptr, &IpInstance, (UCHAR *)"DNS Client");

  /* Is the DNS client configured for the host application to create the packet pool?  */
#ifdef NX_DNS_CLIENT_USER_CREATE_PACKET_POOL
  if (status == NX_SUCCESS)
  {
    /* Yes, use the packet pool created above which has appropriate payload size
       for DNS messages.  */
    status = nx_dns_packet_pool_set(dns_ptr, IpInstance.nx_ip_default_packet_pool);
    if (status != NX_SUCCESS)
    {
      nx_dns_delete(dns_ptr);
    }
  }
#endif /* NX_DNS_CLIENT_USER_CREATE_PACKET_POOL */

#ifdef USER_DNS_ADDRESS
  dns_server_address[0] = USER_DNS_ADDRESS;
#endif /* USER_DNS_ADDRESS */

  if (status != NX_SUCCESS)
  {
    printf("nx_dns_create fail: %u\r\n", status);
    Error_Handler();
  }

  /* Initialize DNS instance with a DNS server address */
  status = nx_dns_server_add(dns_ptr, dns_server_address[0]);
  if (status != NX_SUCCESS)
  {
    printf("nx_dns_server_add fail: %u\r\n", status);
    Error_Handler();
  }

  PRINT_IP_ADDRESS("DNS Server address:", dns_server_address[0]);

  return (status);
}


static UINT unix_time_get(ULONG *unix_time)
{
  /* Return number of seconds since Unix Epoch (1/1/1970 00:00:00).  */
  *unix_time =  (unix_time_base + GetTimeInSeconds()-5)*3600; // converts unix time to ET time

  return (NX_SUCCESS);
}


/* Sync up the local time with a known SNTP server. */
static UINT sntp_time_sync_internal(ULONG sntp_server_address)
{
  ULONG initial_sys_time, initial_sntp_time;
  ULONG current_sys_time, current_sntp_time;
  ULONG initial_time, last_update_time, current_time;
  ULONG elapsed_time=0;
  ULONG drift;
  UINT ret;

  /* Create the SNTP Client to run in broadcast mode.. */
  ret = nx_sntp_client_create(&SntpClient, &IpInstance, 0, &AppPool,
                              NX_NULL,
                              NX_NULL,
                              NX_NULL /* no random_number_generator callback */);

  /* Check status.  */
  if (ret != NX_SUCCESS)
  {
    printf("nx_sntp_client_create fail: %u\r\n", ret);
    return ret;
  }

  PRINT_IP_ADDRESS("Trying SNTP server:", sntp_server_address);

  /* Use the IPv4 service to initialize the Client and set the IPv4 SNTP server. */
  ret = nx_sntp_client_initialize_unicast(&SntpClient, sntp_server_address);

  /* Check status.  */
  if (ret != NX_SUCCESS)
  {
    printf("nx_sntp_client_initialize_unicast fail: %u\r\n", ret);
    nx_sntp_client_delete(&SntpClient);
    return ret;
  }

  /* Set local time to 0 */
  ret = nx_sntp_client_set_local_time(&SntpClient, 0, 0);

  /* Check status.  */
  if (ret != NX_SUCCESS)
  {
    printf("nx_sntp_client_set_local_time fail: %u\r\n", ret);
    nx_sntp_client_delete(&SntpClient);
    return ret;
  }

  /* Run Unicast client */
  ret = nx_sntp_client_run_unicast(&SntpClient);

  /* Check status.  */
  if (ret != NX_SUCCESS)
  {
    printf("nx_sntp_client_run_unicast fail: %u\r\n", ret);
    nx_sntp_client_stop(&SntpClient);
    nx_sntp_client_delete(&SntpClient);
    return ret;
  }

  /* Wait till updates are received */
  for (uint32_t i = 0; i < SNTP_UPDATE_MAX; i++)
  {
    UINT server_status;

    /* First verify we have a valid SNTP service running. */
    ret = nx_sntp_client_receiving_updates(&SntpClient, &server_status);

    /* Check status.  */
    if ((ret == NX_SUCCESS) && (server_status == NX_TRUE))
    {
      /* Server status is good. Now get the Client local time. */
      ULONG sntp_seconds;
      ULONG sntp_fraction;
      ULONG sntp_drift;
      ULONG system_time_in_seconds;
      CHAR time_buffer[64];
      UINT buffer_size=sizeof(time_buffer);

      /* Get the local time. */
      ret = nx_sntp_client_get_local_time_extended(&SntpClient,
                                                   &sntp_seconds, &sntp_fraction,
                                                   NULL, 0);
      //printf("SNTP time in seconds: %lu\n",sntp_seconds);
      sntp_usec = ((uint64_t)sntp_fraction*64103/NTP_FRACTIONAL_RESOLUTION);
      /* Check status. */
      if (ret != NX_SUCCESS){
        continue;
      }

      ret = _nx_sntp_client_utility_display_date_time(&SntpClient, time_buffer, buffer_size);
	  if (ret == NX_SUCCESS){
		  printf("Current SNTP Time in UTC: %s\n", time_buffer);
	  }
	  else{
		  printf("Failed to retrieve SNTP Time\n");
	  }

	  initial_sys_time = GetTimeInSeconds()*1000000; // in microseconds
	  printf("Initial Time: %lu\n",initial_sys_time);
#if 0
	  /* Sync the system time with the SNTP server */
	  while (elapsed_time <= SYNC_DURATION)
	  {
	      // Fetch the current time from the SNTP server
	      ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction, NULL, 0);

	      if (ret == NX_SUCCESS)
	      {
	          // Convert SNTP time to microseconds
	          uint64_t sntp_usec = ((uint64_t)sntp_fraction * 1000000) / NTP_FRACTIONAL_RESOLUTION;
	          uint64_t sntp_time = ((uint64_t)sntp_seconds * 1000000) + sntp_usec;

	          // Fetch the current system time in microseconds
	          uint64_t system_time = GetTimeInSeconds()/(10^6); // Adjust for your system's API

	          // Calculate the drift
	          int64_t drift = sntp_time - system_time;

	          printf("SNTP Time: %lu, System Time: %lu, Drift: %ld\n", (ULONG)sntp_time, (ULONG)system_time, (LONG)drift);

	          // If drift exceeds threshold, adjust the system clock
	          if (abs(drift) > DRIFT_THRESHOLD_SECONDS)
	          {
	              printf("Adjusting system time by drift: %ld seconds\n", drift);
	              system_time += drift;
	          }

	          system_time = sntp_time;
	          // Update last synchronization time
	          //last_update_time = elapsed_time;
	      }
	      else
	      {
	          printf("Failed to fetch SNTP time, error: %u\n", ret);
	      }

	      // Increment elapsed time
	      elapsed_time += SYNC_INTERVAL_SECONDS;

	      // Sleep for the synchronization interval
	      tx_thread_sleep(SYNC_INTERVAL_TICKS);
	  }
#endif
	  /*while(elapsed_time<=30) {
		  // SNTP Time
		  if((elapsed_time-last_update_time)>=10){
			  ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction, NULL, 0);
				if (ret == NX_SUCCESS) {
					current_sntp_time = sntp_seconds;
					last_update_time = elapsed_time; // Update the last update time
					initial_time = GetTimeInSeconds(); // retrieve initial time
					printf("Updated current_time from SNTP: %lu | ", current_sntp_time);
				} else {
					printf("Failed to update time from SNTP\n");
				}
		  }
		  else{
			  //get current time in seconds
			  current_sntp_time += GetTimeInSeconds()-initial_time;
			  //printf("Breakpoint1: %lu\n",current_time);
			  //printf("Current_time_in_seconds: %lu\n", current_time);
			  ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction,NULL, 0);

			  //printf("SNTP time breakpoint: %lu\n",sntp_seconds);

			  if (ret == NX_SUCCESS) {
				// SNTP Drift Calculation
				sntp_drift = sntp_seconds - current_sntp_time;
				printf("Drift in sec: %lu | ", sntp_drift);
				current_sntp_time = sntp_seconds;
			} else {
				printf("Failed to get SNTP time\n");
			}
		  }
		  elapsed_time += 1;
		  tx_thread_sleep(100); // delay

		  // System Time
		  current_sys_time = GetTimeInSeconds();
		  //printf("Current System Time: %lu \n",current_sys_time);
		  ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction, NULL, 0);
		  if (ret != NX_SUCCESS) {
			 printf("nx_sntp_client_get_local_time_extended fail: %u\n", ret);
			 continue;
		  }
		  current_sntp_time = sntp_usec/10^6;
		  //printf("SNTP time current: %lu \n",current_sntp_time);
		  //printf("SNTP time initial: %lu \n",initial_sntp_time);
		  //Drift calculation (overall)
		  drift = (current_sntp_time-initial_sntp_time)-(current_sys_time-initial_sys_time);
		  printf("Drift in sec: %lu | ", drift);
		  elapsed_time += 4;
		  tx_thread_sleep(400); // delay
	  }*/

      /*while(elapsed_time<=30){
       		  current_sys_time = GetTimeInSeconds();
       		  printf("Current System Time: %lu \n",current_sys_time);
       		  ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction, NULL, 0);
       		  if (ret != NX_SUCCESS)
       		 {
       			 printf("nx_sntp_client_get_local_time_extended fail: %u\n", ret);
       			 continue;
       		 }
       		  current_sntp_time = sntp_usec/10^6;
       		  printf("SNTP time current: %lu \n",current_sntp_time);
       		  printf("SNTP time initial: %lu \n",initial_sntp_time);
       		  //Drift calculation
       		  drift = (current_sntp_time-initial_sntp_time)-(current_sys_time-initial_sys_time);
       		  printf("Drift in sec: %lu | ", drift);
       		  elapsed_time += 4;
       		  tx_thread_sleep(400); //delay of 4 seconds
      }*/

	  for (int j = 0; j < 100; j++) {
		 // Get the current system time in seconds
		 system_time_in_seconds = tx_time_get() / TX_TIMER_TICKS_PER_SECOND;

		 // Print the system time
		 printf("System Time: %lu seconds\n", system_time_in_seconds);
		 // SNTP Time
		 if((system_time_in_seconds-last_update_time)>=10){
			  ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction, NULL, 0);
				if (ret == NX_SUCCESS) {
					current_sntp_time = sntp_seconds;
					last_update_time = system_time_in_seconds; // Update the last update time
					initial_time = 0; // retrieve initial time
					printf("Updated current_time from SNTP: %lu | ", current_sntp_time);
				} else {
					printf("Failed to update time from SNTP\n");
				}
		  }
		  else{
			  //get current time in seconds
			  current_sntp_time = ret;
			  //printf("Breakpoint1: %lu\n",current_time);
			  //printf("Current_time_in_seconds: %lu\n", current_time);
			  ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction,NULL, 0);

			  //printf("SNTP time breakpoint: %lu\n",sntp_seconds);

			  if (ret == NX_SUCCESS) {
				// SNTP Drift Calculation
				sntp_drift = (sntp_seconds - current_sntp_time)/1000000;
				printf("SNTP Drift in sec: %ld | ", sntp_drift);
				current_sntp_time = sntp_seconds;
			} else {
				printf("Failed to get SNTP time\n");
			}
		  }
		  tx_thread_sleep(100); // delay

		  // System Time
		  //printf("Current System Time: %lu \n",current_sys_time);
		  ret = nx_sntp_client_get_local_time_extended(&SntpClient, &sntp_seconds, &sntp_fraction, NULL, 0);
		  if (ret != NX_SUCCESS) {
			 printf("nx_sntp_client_get_local_time_extended fail: %u\n", ret);
			 continue;
		  }
		  current_sntp_time = sntp_usec/1000000;
		  //printf("SNTP time current: %lu \n",current_sntp_time);
		  //printf("SNTP time initial: %lu \n",initial_sntp_time);
		  //Drift calculation (overall)
		  drift = system_time_in_seconds - sntp_drift;
		  printf("Drift in sec: %lu | ", drift);
		  tx_thread_sleep(400); // delay

		 // Delay for 1 second
		 tx_thread_sleep(TX_TIMER_TICKS_PER_SECOND); // Using ThreadX's sleep function
	  }

      /* Get the system time in second. */
      system_time_in_seconds = tx_time_get() / TX_TIMER_TICKS_PER_SECOND;

      //printf("System time in seconds: %lu\n",system_time_in_seconds);

      /* Convert to Unix epoch and minus the current system time.  */
      unix_time_base = (sntp_seconds - (system_time_in_seconds + EPOCH_TIME_DIFF));
      //printf("Unix time base: %lu\n",unix_time_base);

      /* Stop and delete SNTP. */
      nx_sntp_client_stop(&SntpClient);
      nx_sntp_client_delete(&SntpClient);

      return NX_SUCCESS;
    }

    /* Sleep.  */
    tx_thread_sleep(SNTP_UPDATE_INTERVAL);
  }

  /* Time sync failed.  */

  /* Stop and delete SNTP.  */
  nx_sntp_client_stop(&SntpClient);
  nx_sntp_client_delete(&SntpClient);

  /* Return success.  */
  return NX_NOT_SUCCESSFUL;
}

/* walk through the list of SNTP servers to find one to synchronize time */
static UINT sntp_time_sync(VOID)
{
  UINT status;
  ULONG sntp_server_address[3];

  /* If no NTP server address obtained with DHCP then try with official list */
  for (uint32_t i = 0; i < SNTP_SYNC_MAX; i++)
  {
    printf("SNTP Time Sync... %s\r\n", sntp_servers[sntp_server_index]);

    /* Make sure the link is up. */
    ULONG link_status;
    status = nx_ip_interface_status_check(&IpInstance, 0U, NX_IP_LINK_ENABLED, &link_status, NX_WAIT_FOREVER);
    if (status == NX_SUCCESS)
    {
      /* Look up SNTP Server address. */
      status = nx_dns_host_by_name_get(&DnsClient, (UCHAR *)sntp_servers[sntp_server_index], &sntp_server_address[0],
                                       5 * NX_IP_PERIODIC_RATE);
    }

    /* Check status.  */
    if (status == NX_SUCCESS)
    {
      /* Start SNTP to sync the local time. */
      status = sntp_time_sync_internal(sntp_server_address[0]);

      /* Check status.  */
      if (status == NX_SUCCESS)
      {
        return NX_SUCCESS;
      }
    }

    /* Switch SNTP server every time. */
    sntp_server_index = (sntp_server_index + 1) % (sizeof(sntp_servers) / sizeof(sntp_servers[0]));
  }

  return NX_NOT_SUCCESSFUL;
}
/* USER CODE END 1 */
